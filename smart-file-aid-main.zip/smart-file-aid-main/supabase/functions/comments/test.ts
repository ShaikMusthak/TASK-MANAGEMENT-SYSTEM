/**
 * Automated tests for Comments API
 * 
 * To run these tests:
 * 1. Install Deno: https://deno.land/manual/getting_started/installation
 * 2. Run: deno test --allow-net --allow-env supabase/functions/comments/test.ts
 */

import { assertEquals, assertExists } from "https://deno.land/std@0.168.0/testing/asserts.ts";

const FUNCTION_URL = Deno.env.get("SUPABASE_URL") + "/functions/v1/comments";
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY");

// Mock data for testing
const mockTaskId = "00000000-0000-0000-0000-000000000000"; // Replace with actual task ID
const mockUserId = "00000000-0000-0000-0000-000000000000"; // Replace with actual user ID
let testCommentId: string;

/**
 * Test: POST - Create a new comment
 */
Deno.test("POST /comments - should create a new comment", async () => {
  const response = await fetch(FUNCTION_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${ANON_KEY}`,
    },
    body: JSON.stringify({
      content: "This is a test comment",
      task_id: mockTaskId,
    }),
  });

  const data = await response.json();
  
  assertEquals(response.status, 201);
  assertExists(data.data);
  assertExists(data.data.id);
  assertEquals(data.data.content, "This is a test comment");
  
  testCommentId = data.data.id;
});

/**
 * Test: POST - Validate required fields
 */
Deno.test("POST /comments - should return error for missing content", async () => {
  const response = await fetch(FUNCTION_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${ANON_KEY}`,
    },
    body: JSON.stringify({
      task_id: mockTaskId,
    }),
  });

  const data = await response.json();
  
  assertEquals(response.status, 400);
  assertExists(data.error);
});

/**
 * Test: POST - Validate content length
 */
Deno.test("POST /comments - should return error for empty content", async () => {
  const response = await fetch(FUNCTION_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${ANON_KEY}`,
    },
    body: JSON.stringify({
      content: "   ",
      task_id: mockTaskId,
    }),
  });

  const data = await response.json();
  
  assertEquals(response.status, 400);
  assertEquals(data.error, "content cannot be empty");
});

/**
 * Test: POST - Validate max content length
 */
Deno.test("POST /comments - should return error for content over 1000 characters", async () => {
  const longContent = "a".repeat(1001);
  
  const response = await fetch(FUNCTION_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${ANON_KEY}`,
    },
    body: JSON.stringify({
      content: longContent,
      task_id: mockTaskId,
    }),
  });

  const data = await response.json();
  
  assertEquals(response.status, 400);
  assertEquals(data.error, "content must be less than 1000 characters");
});

/**
 * Test: GET - Fetch comments for a task
 */
Deno.test("GET /comments - should fetch comments for a task", async () => {
  const response = await fetch(`${FUNCTION_URL}?task_id=${mockTaskId}`, {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${ANON_KEY}`,
    },
  });

  const data = await response.json();
  
  assertEquals(response.status, 200);
  assertExists(data.data);
  assertEquals(Array.isArray(data.data), true);
});

/**
 * Test: GET - Validate required task_id parameter
 */
Deno.test("GET /comments - should return error without task_id", async () => {
  const response = await fetch(FUNCTION_URL, {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${ANON_KEY}`,
    },
  });

  const data = await response.json();
  
  assertEquals(response.status, 400);
  assertEquals(data.error, "task_id is required");
});

/**
 * Test: PUT - Update a comment
 */
Deno.test("PUT /comments - should update a comment", async () => {
  const response = await fetch(`${FUNCTION_URL}?id=${testCommentId}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${ANON_KEY}`,
    },
    body: JSON.stringify({
      content: "This is an updated test comment",
    }),
  });

  const data = await response.json();
  
  assertEquals(response.status, 200);
  assertExists(data.data);
  assertEquals(data.data.content, "This is an updated test comment");
});

/**
 * Test: PUT - Validate required fields for update
 */
Deno.test("PUT /comments - should return error for missing content", async () => {
  const response = await fetch(`${FUNCTION_URL}?id=${testCommentId}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${ANON_KEY}`,
    },
    body: JSON.stringify({}),
  });

  const data = await response.json();
  
  assertEquals(response.status, 400);
  assertEquals(data.error, "content is required");
});

/**
 * Test: PUT - Validate comment ID is required
 */
Deno.test("PUT /comments - should return error without comment id", async () => {
  const response = await fetch(FUNCTION_URL, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${ANON_KEY}`,
    },
    body: JSON.stringify({
      content: "Updated content",
    }),
  });

  const data = await response.json();
  
  assertEquals(response.status, 400);
  assertEquals(data.error, "comment id is required");
});

/**
 * Test: DELETE - Delete a comment
 */
Deno.test("DELETE /comments - should delete a comment", async () => {
  const response = await fetch(`${FUNCTION_URL}?id=${testCommentId}`, {
    method: "DELETE",
    headers: {
      "Authorization": `Bearer ${ANON_KEY}`,
    },
  });

  const data = await response.json();
  
  assertEquals(response.status, 200);
  assertEquals(data.message, "Comment deleted successfully");
});

/**
 * Test: DELETE - Validate comment ID is required
 */
Deno.test("DELETE /comments - should return error without comment id", async () => {
  const response = await fetch(FUNCTION_URL, {
    method: "DELETE",
    headers: {
      "Authorization": `Bearer ${ANON_KEY}`,
    },
  });

  const data = await response.json();
  
  assertEquals(response.status, 400);
  assertEquals(data.error, "comment id is required");
});

/**
 * Test: Invalid HTTP method
 */
Deno.test("PATCH /comments - should return error for unsupported method", async () => {
  const response = await fetch(FUNCTION_URL, {
    method: "PATCH",
    headers: {
      "Authorization": `Bearer ${ANON_KEY}`,
    },
  });

  const data = await response.json();
  
  assertEquals(response.status, 405);
  assertEquals(data.error, "Method not allowed");
});

/**
 * Test: CORS headers
 */
Deno.test("OPTIONS /comments - should return CORS headers", async () => {
  const response = await fetch(FUNCTION_URL, {
    method: "OPTIONS",
  });

  assertEquals(response.status, 200);
  assertEquals(response.headers.get("Access-Control-Allow-Origin"), "*");
  assertExists(response.headers.get("Access-Control-Allow-Headers"));
});