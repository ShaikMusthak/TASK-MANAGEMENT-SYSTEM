import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, MessageSquare, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { EditTaskDialog } from "./EditTaskDialog";
import { CommentList } from "./CommentList";
import { AddCommentDialog } from "./AddCommentDialog";

interface Task {
  id: string;
  title: string;
  description: string | null;
  status: string;
  priority: string;
  created_at: string;
}

interface TaskCardProps {
  task: Task;
  onUpdate: () => void;
}

export function TaskCard({ task, onUpdate }: TaskCardProps) {
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [showAddComment, setShowAddComment] = useState(false);
  const { toast } = useToast();

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive";
      case "medium":
        return "warning";
      case "low":
        return "secondary";
      default:
        return "secondary";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "success";
      case "in_progress":
        return "default";
      case "pending":
        return "secondary";
      default:
        return "secondary";
    }
  };

  const handleDelete = async () => {
    try {
      const { error } = await supabase.from("tasks").delete().eq("id", task.id);

      if (error) throw error;

      toast({
        title: "Task deleted",
        description: "The task has been deleted successfully.",
      });
      onUpdate();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-xl">{task.title}</CardTitle>
              {task.description && (
                <CardDescription className="mt-2">{task.description}</CardDescription>
              )}
            </div>
            <div className="flex gap-2 ml-4">
              <Button size="icon" variant="ghost" onClick={() => setShowEditDialog(true)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="ghost" onClick={handleDelete}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2 mb-4">
            <Badge variant={getPriorityColor(task.priority) as any}>
              {task.priority}
            </Badge>
            <Badge variant={getStatusColor(task.status) as any}>
              {task.status.replace("_", " ")}
            </Badge>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowComments(!showComments)}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              {showComments ? "Hide Comments" : "View Comments"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowAddComment(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Comment
            </Button>
          </div>
          {showComments && (
            <div className="mt-4">
              <CommentList taskId={task.id} />
            </div>
          )}
        </CardContent>
      </Card>

      <EditTaskDialog
        task={task}
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
        onUpdate={onUpdate}
      />

      <AddCommentDialog
        taskId={task.id}
        open={showAddComment}
        onOpenChange={setShowAddComment}
        onCommentAdded={() => {
          onUpdate();
          setShowComments(true);
        }}
      />
    </>
  );
}