import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { EditCommentDialog } from "./EditCommentDialog";

interface Comment {
  id: string;
  content: string;
  created_at: string;
  updated_at: string;
}

interface CommentListProps {
  taskId: string;
}

export function CommentList({ taskId }: CommentListProps) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingComment, setEditingComment] = useState<Comment | null>(null);
  const { toast } = useToast();

  const fetchComments = async () => {
    try {
      const { data, error } = await supabase.functions.invoke("comments", {
        method: "GET",
        body: { task_id: taskId },
      });

      if (error) throw error;

      setComments(data.data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load comments: " + error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, [taskId]);

  const handleDelete = async (commentId: string) => {
    try {
      const { error } = await supabase.functions.invoke("comments", {
        method: "DELETE",
        body: { id: commentId },
      });

      if (error) throw error;

      toast({
        title: "Comment deleted",
        description: "The comment has been deleted successfully.",
      });
      fetchComments();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-4">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (comments.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground">
        No comments yet. Be the first to add one!
      </div>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {comments.map((comment) => (
          <div
            key={comment.id}
            className="p-3 border rounded-lg bg-card"
          >
            <div className="flex items-start justify-between gap-2">
              <p className="text-sm flex-1">{comment.content}</p>
              <div className="flex gap-1">
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7"
                  onClick={() => setEditingComment(comment)}
                >
                  <Pencil className="h-3 w-3" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7"
                  onClick={() => handleDelete(comment.id)}
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}
            </p>
          </div>
        ))}
      </div>

      {editingComment && (
        <EditCommentDialog
          comment={editingComment}
          open={!!editingComment}
          onOpenChange={(open) => !open && setEditingComment(null)}
          onUpdate={fetchComments}
        />
      )}
    </>
  );
}